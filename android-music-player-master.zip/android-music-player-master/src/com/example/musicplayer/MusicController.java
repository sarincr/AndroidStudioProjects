package com.example.musicplayer;

import android.content.Context;
import android.widget.MediaController;

/*
 * This is demo code to accompany the Mobiletuts+ series:
 * Android SDK: Creating a Music Player
 * 
 * Sue Smith - February 2014
 */

public class MusicController extends MediaController {

	public MusicController(Context c){
		super(c);
	}

	public void hide(){}

}
